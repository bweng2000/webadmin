/**
 * This file adds all rows to the table using ajax
 */

function addToTable(tableData) {
	for(var i=0; i<tableData.length; i++) {
		
	}
}